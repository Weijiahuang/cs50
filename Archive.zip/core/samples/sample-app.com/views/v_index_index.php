<p>
	Hello World! You have successfully spawned a new application.
</p>

<p>
	This message is being triggered via the c_index.php controller, within the index() method.
</p>

<p>
	<strong>Since everything is in working order, you should now delete <?php echo APP_PATH?>diagnostics.php</strong>
</p>