<?php
class practice_controller extends base_controller
{
	public function test1() 
	{
	echo "You are looking at test1."
	}
}
?>
