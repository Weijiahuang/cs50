<?php

# Example:
	//define('ENABLE_SOME_NEW_FEATURE', TRUE);